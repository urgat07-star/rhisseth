"use strict";

const RADIUS = 80;
const HEX_WIDTH = Math.sqrt(3) * RADIUS;
const MAP_WIDTH = 3200;
const MAP_HEIGHT = 2200;
const VERSION = "Rhisseth · Artistic V6 · интерактивная сетка";
const API_BASE = "/api";
let csrfToken = '';
let canEdit = false;
let userId = '', editingTerritoryName = false;
let mapRows = [];

const overlay = document.querySelector("#hex-overlay");
const viewport = document.querySelector("#map-viewport");
const loading = document.querySelector("#loading");
const card = document.querySelector("#hex-card");
let selectedHex = null;
let selectedRow = null;
const form = document.querySelector("#hex-form");
const saveStatus = document.querySelector("#save-status");

function polygonPoints(q, r) {
  const cx = HEX_WIDTH * (q + r / 2);
  const cy = RADIUS * 1.5 * r;
  return Array.from({ length: 6 }, (_, index) => {
    const angle = (60 * index - 30) * Math.PI / 180;
    return `${(cx + RADIUS * Math.cos(angle)).toFixed(2)},${(cy + RADIUS * Math.sin(angle)).toFixed(2)}`;
  }).join(" ");
}

function rating(value, maximum) {
  if (!value) return "Нет данных";
  const numeric = Math.max(0, Math.min(maximum, Number.parseInt(value, 10)));
  return `<span class="rating" aria-label="${numeric} из ${maximum}">${"●".repeat(numeric)}${"○".repeat(maximum - numeric)}</span> ${value}/${maximum}`;
}

function positionCard(clientX, clientY) {
  const bounds = viewport.getBoundingClientRect();
  const width = card.offsetWidth || 310;
  const height = card.offsetHeight || 260;
  const left = Math.min(clientX - bounds.left + 14, bounds.width - width - 12);
  const top = Math.min(clientY - bounds.top + 14, bounds.height - height - 12);
  card.style.left = `${Math.max(12, left)}px`;
  card.style.top = `${Math.max(12, top)}px`;
}

function showCard(row, event, polygon) {
  selectedHex?.classList.remove("selected");
  selectedHex = polygon;
  selectedRow = row;
  selectedHex.classList.add("selected");
  document.querySelector("#card-title").textContent = row['Название'] || `Q${row.Q} · R${row.R}`;
  document.querySelector("#card-coordinates").textContent = `Q = ${row.Q}, R = ${row.R}`;
  form.elements[0].name = 'Название';
  Array.from(form.elements).forEach((element) => {
    if (element.name) element.value = row[element.name] ?? "";
  });
  form.hidden = true;
  document.querySelector('#edit-name').hidden = !canEdit;
  document.querySelector('#edit-territory-name').hidden = !(canEdit || row['Тип владельца']==='Игрок' && row['Владелец']===userId);
  form.elements[0].name = 'Название';
  const details = document.querySelector('#hex-details');
  details.replaceChildren();
  for (const [key,label] of [['Название территории','Территория'],['Категория','Категория'],['Тип местности','Ландшафт'],['Дополнительный объект','Объект'],['Проходимость','Проходимость'],['Защита','Защита'],['Плодородие','Плодородие'],['Опасность','Опасность'],['Основной ресурс','Ресурс'],['Богатство ресурса','Богатство'],['Тип владельца','Владение'],['Имя владельца','Владелец'],['Комментарий','Комментарий']]) {
    const line = document.createElement('div'), term = document.createElement('dt'), value = document.createElement('dd');
    term.textContent = label; value.textContent = row[key] || 'Нет данных';
    if (key === 'Тип местности' && row['Состав ландшафта']) {
      try { value.textContent = JSON.parse(row['Состав ландшафта']).map(p => document.querySelector('#show-percentages').checked ? `${p.name} ${p.percent}%` : p.name).join(' / '); } catch {}
    }
    line.append(term,value); details.append(line);
  }
  saveStatus.textContent = "";
  saveStatus.classList.remove("error");
  card.hidden = false;
  positionCard(event.clientX, event.clientY);
}

function closeCard() {
  card.hidden = true;
  selectedHex?.classList.remove("selected");
  selectedHex = null;
  selectedRow = null;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!selectedRow) return;
  const rowBeingSaved = selectedRow;
  if (!window.confirm(`Сохранить название «${form.elements[0].value}»?`)) return;
  const button = form.querySelector("button[type=submit]");
  const payload = Object.fromEntries(new FormData(form).entries());
  button.disabled = true;
  saveStatus.textContent = "Сохранение…";
  saveStatus.classList.remove("error");
  try {
    const response = await fetch(`${API_BASE}/hexes/${rowBeingSaved.Q}/${rowBeingSaved.R}${editingTerritoryName?'/territory-name':''}`, {
      method: editingTerritoryName ? 'PATCH' : 'PUT',
      headers: { "Content-Type": "application/json", "X-CSRF-Token": csrfToken, 'X-Hex-Revision':rowBeingSaved._revision || '' },
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
    Object.assign(rowBeingSaved, result.row);
    if (editingTerritoryName) {
      const refreshed = await fetch(`${API_BASE}/hexes`, {cache:'no-store'});
      if (refreshed.ok) {
        const byCoordinates = new Map((await refreshed.json()).map(row=>[`${row.Q},${row.R}`,row]));
        mapRows.forEach(row=>Object.assign(row,byCoordinates.get(`${row.Q},${row.R}`)||{}));
      }
    }
    if (selectedRow !== rowBeingSaved) return;
    const bounds = selectedHex.getBoundingClientRect();
    showCard(rowBeingSaved,{clientX:bounds.right,clientY:bounds.top},selectedHex);
    saveStatus.textContent = "Сохранено в PostgreSQL";
  } catch (error) {
    if (selectedRow === rowBeingSaved) {
      saveStatus.textContent = `Ошибка: ${error.message}`;
      saveStatus.classList.add("error");
    }
  } finally {
    button.disabled = false;
  }
});

function render(rows) {
  const fragment = document.createDocumentFragment();
  const byCoordinates = new Map(rows.map((row) => [`${Number(row.Q)},${Number(row.R)}`, row]));
  const visibleRows = [];
  // Include every cell intersecting the image, independent of legacy terrain labels.
  for (let r = 0; r < Math.ceil((MAP_HEIGHT + RADIUS) / (RADIUS * 1.5)); r++) {
    const firstQ = Math.ceil(-0.5 - r / 2);
    const lastQ = Math.floor(MAP_WIDTH / HEX_WIDTH + 0.5 - r / 2);
    for (let q = firstQ; q <= lastQ; q++) {
      visibleRows.push(byCoordinates.get(`${q},${r}`) ?? { Q: String(q), R: String(r) });
    }
  }
  visibleRows.forEach((row) => {
    const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    polygon.setAttribute("points", polygonPoints(Number(row.Q), Number(row.R)));
    polygon.setAttribute("class", "hex-hit");
    polygon.setAttribute("tabindex", "0");
    polygon.setAttribute("aria-label", `Гекс Q ${row.Q}, R ${row.R}: ${row["Тип местности"] || "Нет данных"}`);
    polygon.addEventListener("contextmenu", (event) => { event.preventDefault(); showCard(row, event, polygon); });
    polygon.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        const bounds = polygon.getBoundingClientRect();
        showCard(row, { clientX: bounds.right, clientY: bounds.top }, polygon);
      }
    });
    fragment.appendChild(polygon);
  });
  mapRows = visibleRows;
  overlay.appendChild(fragment);
}

document.querySelector("#close-card").addEventListener("click", closeCard);
document.querySelector('#show-percentages').checked = localStorage.getItem('rhisseth-show-percentages') !== 'false';
document.querySelector('#show-percentages').addEventListener('change', event => {
  localStorage.setItem('rhisseth-show-percentages', String(event.target.checked));
  if (selectedRow) showCard(selectedRow, {clientX:viewport.getBoundingClientRect().left+parseFloat(card.style.left),clientY:viewport.getBoundingClientRect().top+parseFloat(card.style.top)},selectedHex);
});
document.querySelector('#edit-name').addEventListener('click', () => {
  editingTerritoryName = false;
  document.querySelector('#name-label').textContent = 'Географическое название';
  form.elements[0].name = 'Название';
  form.elements[0].value = selectedRow['Название'] || '';
  form.hidden = false;
  document.querySelector('#edit-name').hidden = true;
  form.elements.namedItem('Название').focus();
});
document.querySelector('#edit-territory-name').addEventListener('click', () => {
  editingTerritoryName = true;
  document.querySelector('#name-label').textContent = 'Название территории';
  form.elements[0].name = 'Название территории';
  form.elements[0].value = selectedRow['Название территории'] || '';
  form.hidden = false;
  form.elements[0].disabled = false;
  form.querySelector('[type=submit]').disabled = false;
  document.querySelector('#cancel-name').disabled = false;
  form.elements[0].focus();
});
document.querySelector('#cancel-name').addEventListener('click', () => {
  form.hidden = true;
  form.elements[0].value = selectedRow?.[form.elements[0].name] || '';
  document.querySelector('#edit-name').hidden = !canEdit;
});
document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeCard(); });
viewport.addEventListener("pointerdown", (event) => { if (!card.contains(event.target) && event.button === 0) closeCard(); });

async function loadData() {
  const identityResponse = await fetch(`${API_BASE}/me`, { cache: "no-store" });
  if (identityResponse.status === 401) {
    window.location.href = '/index.php';
    throw new Error('Требуется вход');
  }
  if (!identityResponse.ok) throw new Error(`HTTP ${identityResponse.status}`);
  const identity = await identityResponse.json();
  csrfToken = identity.csrf;
  canEdit = identity.can_edit;
  userId = identity.id;
  document.querySelector('#admin-link').hidden = !canEdit;
  document.querySelector('#admin-link').href = identity.role === 'admin' ? '/admin/users' : '/admin/hexes';
  document.querySelector('#user-status').textContent = `${identity.login} · ${identity.role}`;
  if (!identity.can_edit) {
    for (const element of form.elements) element.disabled = true;
    document.querySelector('#editor-hint').textContent = 'Режим просмотра · правая кнопка — сведения о гексе';
  }
  const response = await fetch(`${API_BASE}/hexes`, { cache: "no-store" });
  if (!response.ok) throw new Error(`PostgreSQL API: HTTP ${response.status}`);
  return { rows: await response.json(), source: "PostgreSQL" };
}

document.querySelector('#logout').addEventListener('click', async () => {
  const body = new URLSearchParams({ csrf: csrfToken });
  const response = await fetch('/logout', { method: 'POST', body });
  if (response.ok) window.location.href = '/index.php';
});
let startChoices = [], claiming = false;
document.querySelector('#start-game').addEventListener('click', async () => {
  const panel = document.querySelector('#start-panel'), status = document.querySelector('#start-status');
  panel.hidden=false;
  try {
    const response=await fetch('/api/start/options',{cache:'no-store'}), result=await response.json();
    if(!response.ok)throw new Error(result.error);
    const choice=document.querySelector('#barony-choice');choice.replaceChildren();
    startChoices=result.options;
    startChoices.forEach((option,i)=>choice.append(new Option(option.cells.map(c=>`Q${c[0]} R${c[1]}`).join(' · '),String(i))));
    document.querySelector('#claim-choice').disabled=result.started||!startChoices.length;
    document.querySelector('#claim-random').disabled=result.started||!startChoices.length;
    status.textContent=result.started?`Барон · ${result.name}`:startChoices.length?'Выберите территорию или получите случайную баронию':'Свободных бароний пока нет';
  } catch(error){status.textContent=error.message;}
});
document.querySelector('#cancel-start').addEventListener('click',()=>document.querySelector('#start-panel').hidden=true);
async function claimBarony(random) {
  if(claiming)return;
  const payload={name:document.querySelector('#barony-name').value};
  if(!random)payload.cells=startChoices[Number(document.querySelector('#barony-choice').value)]?.cells;
  if(!window.confirm('Подтвердить получение начальной баронии? Выбор выполняется один раз.'))return;
  claiming=true;
  try {
    const response=await fetch('/api/start',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrfToken},body:JSON.stringify(payload)}),result=await response.json();
    if(!response.ok)throw new Error(result.error);
    window.location.reload();
  } catch(error){document.querySelector('#start-status').textContent=error.message;}finally{claiming=false;}
}
document.querySelector('#claim-choice').addEventListener('click',()=>claimBarony(false));
document.querySelector('#claim-random').addEventListener('click',()=>claimBarony(true));

loadData()
  .then(({ rows, source }) => {
    render(rows);
    document.querySelector("#data-status").textContent = `${VERSION} · источник: ${source}`;
    loading.remove();
  })
  .catch((error) => {
    loading.textContent = `Не удалось загрузить данные карты: ${error.message}. Запустите приложение через локальный веб-сервер.`;
    loading.classList.add("error");
  });
